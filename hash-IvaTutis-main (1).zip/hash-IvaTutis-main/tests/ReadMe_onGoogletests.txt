Imala sam problema sa googletestom i linkanjem kompajlera na visual studiu community 2019, tj. uporno nije prepoznavao gtest/gtest.h, a nisam našla rješenje na vrijeme. 
