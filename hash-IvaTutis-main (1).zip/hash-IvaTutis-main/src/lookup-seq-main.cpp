﻿#include "lookup-seq.h"

#include <string>
#include <iostream>

//Napravite jedinične testove u test direktoriju(kreirajte sami) pomoću google test biblioteke.
//Google test smjestiti kao subproject u direktorij external(kreirajte sami).
//Modificirati na odgovarajući način sustav za izgradnju.
//Testirajte sve metode osim metode print() koja služi vama za verifikaciju strukture.
int main() {
    return 0;
}