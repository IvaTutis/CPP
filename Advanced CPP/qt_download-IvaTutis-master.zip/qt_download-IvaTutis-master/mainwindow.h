#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QtWidgets>
#include <QNetworkAccessManager>
#include<QNetworkReply>
#include<LoginWindow.h>
#include<QAuthenticator>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow();


private:
    Ui::MainWindow *ui;
    QWidget * mainWidget = nullptr;

    QVBoxLayout * centralWidgetLayout = nullptr;
    QGridLayout * urlLayout = nullptr;
    QVBoxLayout * textAndheaderLayout = nullptr;
    QHBoxLayout * buttonLayout = nullptr;

    QLabel * urlLabel = nullptr;
    QLineEdit * urlLineEdit = nullptr;
    QPushButton * loadFileButton = nullptr;

    QLabel * textLabel = nullptr;
    QPlainTextEdit * textPlainTextEdit = nullptr;
    QLabel * headersLabel = nullptr;
    QPlainTextEdit * headersPlainTextEdit = nullptr;

    QPushButton * clearButton = nullptr;
    QPushButton * exitButton = nullptr;


    void createWidgets();
    void connectSignals();
    void createNetwork();

    //stvari za network
    QNetworkAccessManager * nam = nullptr;
    QNetworkReply * reply = nullptr;

    void clearPlainTextEditors();
    void connectNetworkActions();
    void loadFile();
    void ReadyRead();
    void Finished();
    void writeHeader(QString string);
    void writeText(QString string);

    //progress bar
    QProgressBar * pb =nullptr;

    void onDownloadProgress(qint64 received, qint64 total);

    //autentifikacija
     LoginWindow * login = nullptr;

     void authentification(QNetworkReply * rep, QAuthenticator* auth);

     //download filea
     bool downloading;
     bool downloaded;
     QTemporaryFile file;

};
#endif // MAINWINDOW_H
