#include "mainwindow.h"
#include <QLabel>
#include <QPixmap>
#include <QMenuBar>
#include <QLabel>
#include <QApplication>
#include <QLineEdit>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include<QMessageBox>

LoginWindow::LoginWindow(){

    //postavljam pass i uname
    pass="x";
    uname="iva";

    mainWidget = new QWidget();
    //izgled glavnog prozora
    setWindowTitle("qt_login");
    resize(400, 100);

    //inicijaliziram dijelove login layouta i stavljam ih u nj
    nameLabel = new QLabel("User name:");
    passLabel = new QLabel("Password:");
    nameLineEdit = new QLineEdit();
    passLineEdit = new QLineEdit();
    passLineEdit->setEchoMode(QLineEdit::Password);

    loginlayout = new QGridLayout();
    loginlayout->addWidget(nameLabel, 0, 0);
    loginlayout->addWidget(nameLineEdit, 0, 1);
    loginlayout->addWidget(passLabel, 1, 0);
    loginlayout->addWidget(passLineEdit, 1, 1);

    //inicijaliziram dijelove button layouta i stavljam ih u nj
    loginButton = new QPushButton("&Submit");
    cancelButton = new QPushButton("&Cancel");

    buttonlayout = new QHBoxLayout();
    buttonlayout->addWidget(cancelButton);
    buttonlayout->addWidget(loginButton);
    //treba linkati actione i buttone?

    //stavljam ta 2 layouta u općeniti layout
    layout= new QVBoxLayout();
    layout->addLayout(loginlayout);
    layout->addLayout(buttonlayout);

    //layout nakeljim
    setLayout(layout);

    spojiSignale();

    //flag
    success=false;

}

void LoginWindow::Login_clicked()
{
    success=false;

    QString username = nameLineEdit->text();
    QString password = passLineEdit->text();

    if(username.isEmpty() || password.isEmpty()){
        QMessageBox::information(this, "Failed", "Try Again?");
        nameLineEdit ->clear();
        passLineEdit ->clear();
    }else{
        uname = username;
        pass = password;
        success=true;
        QDialog::close();
    }

}

void LoginWindow::spojiSignale(){

    connect(cancelButton, &QPushButton::clicked, this, &QDialog::close);
    connect(loginButton, &QPushButton::clicked, this, &LoginWindow::Login_clicked);
}

QString LoginWindow::getPassword()
{
    return pass.trimmed();
}

QString LoginWindow::getUsername()
{
    return uname.trimmed();
}

bool LoginWindow::getSuccess(){return success;};

