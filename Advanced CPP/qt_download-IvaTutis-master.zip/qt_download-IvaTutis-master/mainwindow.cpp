#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QNetworkAccessManager>
#include<QNetworkReply>
#include<QList>
#include<QAuthenticator>
#include<string>

//------------------------. KONSTRUKTOR I POPRATNE FUNKCIJE. -------------------------------

MainWindow::MainWindow()
{
    setWindowTitle("File download");
    resize(500, 500);

    createWidgets();
    connectSignals();
    createNetwork();

    mainWidget ->setLayout(centralWidgetLayout);
    setCentralWidget(mainWidget);
}

//stvara widget - DONE
void MainWindow::createWidgets()
{
    //......inicijalizira glavne vizualne elemente
    mainWidget = new QWidget();
    centralWidgetLayout = new QVBoxLayout();
    textAndheaderLayout = new QVBoxLayout();
    buttonLayout = new QHBoxLayout();

    //.......inicijaliziram elemente za upis url-a
    urlLayout = new QGridLayout();
    urlLabel = new QLabel("URL:");
    urlLineEdit = new QLineEdit();
    loadFileButton = new QPushButton("Load file");
    //dodajemo urlLabel, urlLineEdit i loadFileButton u urlLayout
    urlLayout->addWidget(urlLabel, 0, 0);
    urlLayout->addWidget(urlLineEdit, 0, 1);
    urlLayout->addWidget(loadFileButton, 0, 2);
    //dodajem urlLayout u
    centralWidgetLayout->addLayout(urlLayout);

    //......inicijaliziram dio gdje se ispisuje text_tekstualne_datoteke ili opis_greške
    textLabel = new QLabel("Text:");
    textPlainTextEdit = new QPlainTextEdit();
    textPlainTextEdit->setReadOnly(true);
    //......inicijaliziram dio gdje se ispisuju greške
    headersLabel = new QLabel("Headers:");
    headersPlainTextEdit = new QPlainTextEdit();
    headersPlainTextEdit->setReadOnly(true);
    //dodajem gornje elemente u pripremljeni layout za QPlainText edite i njihove Qlabele
    textAndheaderLayout->addWidget(textLabel);
    textAndheaderLayout->addWidget(textPlainTextEdit);
    textAndheaderLayout->addWidget(headersLabel);
    textAndheaderLayout->addWidget(headersPlainTextEdit);
    //dodajem layout za QPlainText elemente u centralni widget
    centralWidgetLayout->addLayout(textAndheaderLayout);


    //inicijaliziram gumbe, dodajem ih u njhov layout i dodajem u central widget
    clearButton = new QPushButton("Clear");
    exitButton = new QPushButton("Exit");
    buttonLayout->addStretch();
    buttonLayout->addWidget(clearButton);
    buttonLayout->addWidget(exitButton);
    centralWidgetLayout->addLayout(buttonLayout);

    //dodajem progress bar, skrivam ga
    pb = new QProgressBar();
    pb->hide();
    statusBar()->addWidget(pb);

    //autentifikacija
    login = new LoginWindow();

    //download flag
    downloading = false;
    downloaded=false;

}

//inicijalizira network
void MainWindow::createNetwork()
{
    nam = new QNetworkAccessManager(this);
}

//spaja widgete i akcije sa funkcijama
void MainWindow::connectSignals()
{
    connect(exitButton, &QPushButton::clicked, this, QApplication::exit);
    connect(loadFileButton, &QPushButton::clicked,this, &MainWindow::loadFile);
    connect(clearButton, &QPushButton::clicked, this, &MainWindow::clearPlainTextEditors);
}

//----------------------------------. LOAD FILE .--------------------------------------------

//loada file
void MainWindow::loadFile()
{
    //cistim textEditore i generiram novi login window
    clearPlainTextEditors();
    statusBar()->showMessage("");
    login=new LoginWindow();

   //uzima string iz lineeditora, stvaram url iz njega
    QString urlText = urlLineEdit->text().trimmed();
    QUrl url(urlText);

    //radim novi request iz url-a
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::UserAgentHeader, "MyFileDownloader");
    request.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true); //?
    reply = nam->get(request);

    //Kada Network posalje ReadyRead, onda
    connectNetworkActions();

    //za svaki slucaj ako smo prije nesto downloadali, stavljam flag na false
    downloading=false;
}

//čisti unutrašnjost QPlainTextEdit-ova
void MainWindow::clearPlainTextEditors()
{
    textPlainTextEdit->clear();
    headersPlainTextEdit->clear();
}

//spaja ReadyRead i Finished sa odgovarajucim signalima
void MainWindow::connectNetworkActions(){
    connect(reply, &QNetworkReply::readyRead, this, &MainWindow::ReadyRead);
    connect(reply, &QNetworkReply::finished, this, &MainWindow::Finished);
    connect(reply, &QNetworkReply::downloadProgress, this, &MainWindow::onDownloadProgress);
    connect(nam, &QNetworkAccessManager::authenticationRequired, this, &MainWindow::authentification);
}

//-----------------------------. READY READ .--------------------------------
// text example: https://www.w3.org/TR/PNG/iso_8859-1.txt --> works
//download example: ne radi
//autentifikacija: radi

void MainWindow::ReadyRead()
{

    QVariant contentTypeHeader = reply->header(QNetworkRequest::ContentTypeHeader);

    //AKO FILE NIJE TEKSTUALNI MIME TIP
     if( contentTypeHeader.toString()!="text/plain; charset=utf-8"
             && contentTypeHeader.toString()!="text/html; charset=utf-8"
             && contentTypeHeader.toString()!="text/csv; charset=utf-8") downloading=true;
     if(downloading){
         pb->show();

         file.open();

         QTextStream stream(&file);
         file.write(reply->readAll());

         file.close();
         return;
     }

    //OVO SE DESAVA SAMO AKO FILE JE TEXTUALNI MIME TIP

    //ispisujem u text QPlainTextEdit
    QByteArray array = reply->readAll();
    writeText(array);

    //ispisujem u headers QPlainTextEdit
    auto headerPairs = reply -> rawHeaderPairs();
    foreach(auto a, headerPairs)
    {
        QString first =  a.first.toStdString().c_str();
        QString second =  a.second.toStdString().c_str();
        writeHeader(first + ": " + second + "\n");
    }

}

void MainWindow::writeHeader(QString string)
{
    headersPlainTextEdit->moveCursor (QTextCursor::End);
    headersPlainTextEdit->insertPlainText (string);
    headersPlainTextEdit->moveCursor (QTextCursor::End);
}

void MainWindow::writeText(QString string)
{
    textPlainTextEdit->moveCursor (QTextCursor::End);
    textPlainTextEdit->insertPlainText (string);
    textPlainTextEdit->moveCursor (QTextCursor::End);
}


//-------------------------------. FINISH .-----------------------------

//kada je gotov
void MainWindow::Finished()
{
    //ako imam redirect
    QVariant redirectionTarget = reply->attribute(QNetworkRequest::RedirectionTargetAttribute);

    //chekiram jel downloadani temp file moram ispisivati u textbox
    if(downloading==true && reply->error() == QNetworkReply::NoError && redirectionTarget.isNull()){
        file.open();
        QByteArray array = file.readAll();

        writeText(array);

        file.close();

        file.open();
        file.reset();
        file.close();

         return;

    }

    //download, ako se i desio, je gotov
     downloading=false;
     pb->hide();

    //ako imam error
    if(reply->error() != QNetworkReply::NoError)
    {
        auto error = reply->errorString();
        writeText(error);
        statusBar()->showMessage(tr("HTTP Status = %1").arg(reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt()));
    }

    //ako imam redirect
    reply->deleteLater();
    if(!redirectionTarget.isNull())
    {
         QUrl redirectionURL = redirectionTarget.toUrl();
         if(QMessageBox::question(this,"Redirect",tr("Do you want to redirect to %1").arg(redirectionURL.toString())) == QMessageBox::No)
         {
            return;
         }

         //radim novi request na url
         QNetworkRequest request(redirectionURL);
         request.setHeader(QNetworkRequest::UserAgentHeader, "MyFileDownloader");
         request.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true);
         reply = nam->get(request);

         //reconnectam network na tamo
         connectNetworkActions();
    }
}

//------------------------------------. AUTENTIFIKACIJA .--------------------------------
//WORKS!
void MainWindow::authentification(QNetworkReply * reply, QAuthenticator * auth)
{
    if (login->getSuccess()==false)login->exec();

    //saljemo povratnu informaciju ako je imamo
    if (login->getSuccess()==true){
    auth->setUser(login->getUsername());
    auth->setPassword(login->getPassword());
    }
}


//--------------------------------------. PROGRESS BAR .-----------------------------------
void MainWindow::onDownloadProgress(qint64 received, qint64 total)
{
    qreal progress = (total < 1) ? 1.0 : static_cast<qreal>(received)/total;
    pb->setValue(progress * pb->maximum());
}

