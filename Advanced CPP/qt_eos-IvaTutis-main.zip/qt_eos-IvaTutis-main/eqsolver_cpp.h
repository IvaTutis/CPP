#ifndef EQSOLVER_CPP_H
#define EQSOLVER_CPP_H

#include <QObject>
#include <QList>

class eqsolver_cpp : public QObject
{
    Q_OBJECT
public:
    explicit eqsolver_cpp(QObject *parent = nullptr);
    Q_INVOKABLE QList<double> result (double, double, double, double);
    Q_INVOKABLE double cuberoot(double);
signals:

};

#endif // EQSOLVER_CPP_H
