#include "eqsolver_cpp.h"
#include <math.h>
#include <iostream>

eqsolver_cpp::eqsolver_cpp(QObject *parent) : QObject(parent)
{

}

QList<double> eqsolver_cpp::result(double t_qml, double p_qml, double a_qml, double b_qml){

    QList<double> result;

    /* testing

    //test inequal --> works
    result.append(1);
    result.append(2);
    result.append(3);

    //test equal --> works
    result.append(4);
    result.append(4);
    result.append(4);
*/

    //testing uvjeta za racun
    if (t_qml<=0) return std::numeric_limits<QList<double>>::quiet_NaN();

    //radim a,b,c,d i konstantu u kubnoj
    double R=8.314462;
    double a= p_qml;
    double b= - R*t_qml;
    double c= - R*t_qml*b_qml + a_qml/sqrt(t_qml) - b_qml*b_qml*p_qml;
    double d= - a_qml*b_qml/sqrtf(t_qml);

    //racunam q i p
    float q = (3*a*c - b*b)/(3*a);
    float p = (2*b*b*b-9*a*b*c+27*a*a*d)/(27*a*a*a);

    //racunam diskriminantu
     float discriminant = q*q/4 + p*p*p/27;

     std::cout<<" p:"<<p << " q "<< q <<" discriminant: "<<discriminant<< std::endl;

     //inicijaliziram
     double  v1,v2,v3;

     if(discriminant>0){

         v1=cuberoot(-q/2+sqrt(discriminant))+cuberoot(-q/2-sqrt(discriminant))-b/(3*a);


     }else if(discriminant<0){
        double r=sqrt(-p*p*p/27);
         double phi=acos(-q/(2*r));

         v1=2*cuberoot(r)*cos(phi/3)-b/(3*a);
         v2=2*cuberoot(r)*cos(phi/3 + 2*3.14/3)-b/(3*a);
         v3=2*cuberoot(r)*cos(phi/3+4*3.14/3)-b/(3*a);

     }else{
         v1=-2*cuberoot(-q/2)-b/(3*a);
         v2=cuberoot(-q/2)-b/(3*a);
         v3=cuberoot(-q/2)-b/(3*a);
     }


     result.append(v1);
     result.append(v2);
     result.append(v3);


    //cisto da ne baca error
    return result;
}

//pomocna f-ja za cuberoot
double eqsolver_cpp::cuberoot(double x) {
    if (x < 0) {
        return -pow(-x, 1.0/3.0);
    } else if (x > 0) {
        return pow(x, 1.0/3.0);
    } else {
        return 0;
    }
 }
