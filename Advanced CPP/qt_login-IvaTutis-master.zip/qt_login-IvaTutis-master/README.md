**Zadatak**. Potrebno je napraviti malu login aplikaciju. 
Aplikacija otvara sljedeći prozor:

![aplikacija](doc/app.png)

Aplikacija završava ako se klikne na "Cancel". Kada se klikne na "Submit"
provjerava se da li su uneseni podaci jednaki podacima koji su 
zapisani u aplikaciji (možete ime i zaporku zadati u konstruktoru). 
Pri tome zaporka ne smije biti prikazana:

![unos](doc/pass.png)

Ako podaci nisu pogođeni daje se obavijest o tome: 

![neuspjeh](doc/failure.png)

i očekuje se novi upis. Polja za unos moraju biti očišćena. 

Ako su podaci pogođeni javlja se obavijest:

![uspjeh](doc/success.png)

i nakon potvrde (klik na ok) program završava.  
