#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// Vaš kod
#pragma once
#include <QMainWindow>
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QMainWindow>
#include <QMessageBox>


class MainWindow : public QMainWindow{

 Q_OBJECT

public:
    MainWindow();

private:
    void Login_clicked();
    void spojiSignale();

    QWidget * mainWidget = nullptr;

    QString pass;
    QString uname;

    QLabel * nameLabel = nullptr;
    QLabel * passLabel = nullptr;

    QLineEdit * nameLineEdit = nullptr;
    QLineEdit * passLineEdit = nullptr;

    QPushButton * loginButton = nullptr;
    QPushButton * cancelButton= nullptr;


    QVBoxLayout * layout = nullptr;
    QGridLayout * loginlayout = nullptr;
    QHBoxLayout * buttonlayout = nullptr;


};


#endif // MAINWINDOW_H
