#include "mainwindow.h"
#include <QLabel>
#include <QPixmap>
#include <QMenuBar>
#include <QLabel>
#include <QApplication>
#include <QLineEdit>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include<QMessageBox>

MainWindow::MainWindow(){

    //postavljam pass i uname
    pass="x";
    uname="iva";

    mainWidget = new QWidget();
    //izgled glavnog prozora
    setWindowTitle("qt_login");
    resize(400, 100);

    //inicijaliziram dijelove login layouta i stavljam ih u nj
    nameLabel = new QLabel("User name:");
    passLabel = new QLabel("Password:");
    nameLineEdit = new QLineEdit();
    passLineEdit = new QLineEdit();
    passLineEdit->setEchoMode(QLineEdit::Password);

    loginlayout = new QGridLayout();
    loginlayout->addWidget(nameLabel, 0, 0);
    loginlayout->addWidget(nameLineEdit, 0, 1);
    loginlayout->addWidget(passLabel, 1, 0);
    loginlayout->addWidget(passLineEdit, 1, 1);

    //inicijaliziram dijelove button layouta i stavljam ih u nj
    loginButton = new QPushButton("&Submit");
    cancelButton = new QPushButton("&Cancel");

    buttonlayout = new QHBoxLayout();
    buttonlayout->addWidget(cancelButton);
    buttonlayout->addWidget(loginButton);
    //treba linkati actione i buttone?

    //stavljam ta 2 layouta u općeniti layout
    layout= new QVBoxLayout();
    layout->addLayout(loginlayout);
    layout->addLayout(buttonlayout);

    //layout nakeljim na widget
    mainWidget->setLayout(layout);
    setCentralWidget(mainWidget);

    spojiSignale();


}

void MainWindow::Login_clicked()
{
    QString username = nameLineEdit->text();
    QString password = passLineEdit->text();

    if(username ==  uname && password == pass) {
        QMessageBox::information(this, "Sucess", "You have successfully logged in");

    }
    else {
        QMessageBox::warning(this,"Faliure", "Try again");
    }

}

void MainWindow::spojiSignale(){

    connect(cancelButton, &QPushButton::clicked, this, &QApplication::quit);
    connect(loginButton, &QPushButton::clicked, this, &MainWindow::Login_clicked);
}
