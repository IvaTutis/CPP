#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QLabel>
#include <QSpinBox>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QNetworkAccessManager>
#include<QNetworkReply>
#include <QTcpSocket>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    //konstruktor je javan javni
    MainWindow();

private:
    //user interface
    Ui::MainWindow *ui;

    //most important
    QWidget * CentralWidget = nullptr;

    //layouts
    QVBoxLayout * centralwidgetLayout = nullptr;
    QVBoxLayout * serverconfigurationLayout = nullptr;
    QGroupBox * serverconfigurationGroupBox = nullptr;
    QGridLayout * serverdataLayout = nullptr;
    QHBoxLayout * buttonLayout = nullptr;
    QHBoxLayout * textLayout = nullptr;

    //input
    QLineEdit * AdressLineEdit = nullptr;
    QSpinBox * PortSpinBox = nullptr;
    QLineEdit * UserLineEdit = nullptr;
    QLineEdit * TextLineEdit = nullptr;
    QTextEdit * MessageBox =nullptr;

    //labels (names for inputs)
    QLabel * AdressLabel = nullptr;
    QLabel * PortLabel = nullptr;
    QLabel * UserLabel = nullptr;
    QLabel * TextLabel = nullptr;
    QLabel * ServerConfigurationLabel = nullptr;

    //buttons
    QPushButton * ConnectButton = nullptr;
    QPushButton * DisconnectButton = nullptr;

    //stvari vezane za slanje/primanje podataka sa servera
    QTcpSocket * m_socket = nullptr;
    QByteArray m_data;
    QString m_name;

    //funkcije koje zove konstruktor
    void createWidgets();
    void createSocketStuff();
    void connectSignals();

    //funkcije koje zovu gumbi
    void ConnectToHost();
    void FailedToConnect();
    void Connected();
    void OnError();
    void DisconnectButtonPushed();
    void Disconnected();

    //funkcije za pisanje/slanje poruka
    void readyRead();
    void readySend();

    //funkcije za rad sa LineEditsima/PlainTextEditom
    void writeMessageBox(QString s);
    void writeMessageBox(QString s,QString user);
    void lockServerConfiguration();
    void unlockServerConfiguration();
    void ClearLineEdits();
    void ClearSocketStuff();


};
#endif // MAINWINDOW_H
