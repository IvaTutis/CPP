#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMainWindow>
#include <QLineEdit>
#include <QLabel>
#include <QSpinBox>
#include <QPlainTextEdit>
#include <QPushButton>

//-------------------------------. KONSTRUKTOR I VEZANE FUNKCIJE .----------------
MainWindow::MainWindow()
{
    setWindowTitle("TcpClient");
    resize(500, 500);

    createWidgets();
    createSocketStuff();
    connectSignals();

    CentralWidget  ->setLayout(centralwidgetLayout);
    setCentralWidget(CentralWidget);
}

void MainWindow::createWidgets()
{

    //Inicijalizacija
    CentralWidget = new QWidget();
    centralwidgetLayout = new QVBoxLayout();
    serverconfigurationLayout= new QVBoxLayout();
    serverconfigurationGroupBox = new QGroupBox();
    serverdataLayout= new QGridLayout();
    buttonLayout = new QHBoxLayout();
    textLayout = new QHBoxLayout();
    AdressLineEdit = new QLineEdit();
    PortSpinBox = new QSpinBox();
    UserLineEdit = new QLineEdit();
    TextLineEdit = new QLineEdit();
    MessageBox = new QTextEdit();
    AdressLabel = new QLabel("Adress:");
    PortLabel = new QLabel("Port:");
    UserLabel = new QLabel("User:");
    TextLabel = new QLabel("Text:");
    ServerConfigurationLabel = new QLabel("Server Configuration:");
    ConnectButton = new QPushButton("&Connect");
    DisconnectButton = new QPushButton("&Disconnect");

    //prvo pospojimo gornji dio ekrana
    centralwidgetLayout->addWidget(ServerConfigurationLabel);

    //zatim ide grid
    serverdataLayout->addWidget(AdressLabel,0,0);
    serverdataLayout->addWidget(PortLabel,1,0);
    serverdataLayout->addWidget(UserLabel,2,0);
    serverdataLayout->addWidget(AdressLineEdit,0,1);
    serverdataLayout->addWidget(PortSpinBox,1,1);
    serverdataLayout->addWidget(UserLineEdit,2,1);

    serverconfigurationLayout->addLayout(serverdataLayout);

    //zatim idu gumbi
    buttonLayout->addStretch();
    buttonLayout->addWidget(ConnectButton);
    buttonLayout->addWidget(DisconnectButton);
     DisconnectButton->setEnabled(false);

    serverconfigurationLayout->addLayout(buttonLayout);

    //skupa to stavimo u QVBoxLayout pa u Qgroupbox
    serverconfigurationGroupBox->setLayout(serverconfigurationLayout);

    //dodajemo groupboc u glavni layout
    centralwidgetLayout->addWidget(serverconfigurationGroupBox);

    //zatim ide QPlainTextEdit
    centralwidgetLayout->addWidget(MessageBox);

    //zatim ide text
    textLayout->addWidget(TextLabel);
    textLayout->addWidget(TextLineEdit);

    centralwidgetLayout->addLayout(textLayout);
}

void MainWindow::createSocketStuff(){
    m_socket = new QTcpSocket();
    m_name.clear();
    m_data.clear();
}

//spajam signale/Slotove -> probably done
void MainWindow::connectSignals()
{
 //USER INTERACTION
 connect(ConnectButton, &QPushButton::clicked, this, &MainWindow::ConnectToHost);
 connect(DisconnectButton, &QPushButton::clicked, this, &MainWindow::DisconnectButtonPushed);
 connect(TextLineEdit, &QLineEdit::returnPressed, this, &MainWindow::readySend);//po dokumentaciji reagira na enter

 //SOCKET STUFF
 connect(m_socket, &QTcpSocket::connected, this, &MainWindow::Connected);
 connect(m_socket, &QTcpSocket::readyRead, this, &MainWindow::readyRead);
 connect(m_socket, &QTcpSocket::disconnected, this, &MainWindow::Disconnected);

 //ERRORS
 connect(m_socket, &QTcpSocket::errorOccurred, this, &MainWindow::OnError);


}


//-------------------------------. funkcije za connect/disconnect .---------------
//spaja s hostom -> DONE
void MainWindow::ConnectToHost()
{
    lockServerConfiguration();
    // spajamo m_socket ako nije socket konektiran
    if(m_socket->state() != QAbstractSocket::ConnectedState){
            m_socket->connectToHost(AdressLineEdit->text(), PortSpinBox->value());
            m_name = UserLineEdit->text();
            writeMessageBox("Connecting...");
        }
}

//ako se nije uspio konektirati -> DONE
void MainWindow::FailedToConnect()
{
    unlockServerConfiguration();
    ClearSocketStuff();
    writeMessageBox("Failed to connect!");

}

//ako se uspio konektirati -> DONE
void MainWindow::Connected()
{
    DisconnectButton->setEnabled(true);
    writeMessageBox("Ostvarena konekcija sa " + AdressLineEdit->text() + " , port " + PortSpinBox->text());
}

//ako se dogodila greska -> DONE
void MainWindow::OnError()
{
    QString e = tr("Server error: %1").arg(m_socket->errorString());
    writeMessageBox(e);

    if(m_socket->state() != QAbstractSocket::ConnectedState)
    {
        DisconnectButton->setEnabled(false);
    }
    return;
}

//ako smo pushali disconnect button -> DONE
void MainWindow::DisconnectButtonPushed()
{
   writeMessageBox("Disconnecting...");
   m_socket->disconnectFromHost();
}

//disconnectani smo od servera -> DONE
void MainWindow::Disconnected()
{
    writeMessageBox("Disconnected by server");
    DisconnectButton->setEnabled(false);
    ClearSocketStuff();
    unlockServerConfiguration();
}

//-------------------------------. funkcije za primanje/slanje poruka .--------------------

//ako saljemo poruku -> DONE
void MainWindow::readyRead()
{
    //clearing our data storage
    m_data.clear();

    // kreiram & settam verziju
    QDataStream socket_stream(m_socket);
     socket_stream.setVersion(QDataStream::Qt_5_7);

     const char ETB = 23; // End-of-Transmission-Block character
     m_data.append(m_socket->readAll());

     //beskonacna petlja
     while(true){
         int indETB = m_data.indexOf(ETB);

         if(indETB  < 0) break;


         QString message=QString::fromUtf8(m_data.left(indETB));

         //pisem u message box dobivenu poruku
         writeMessageBox(message, "reply");

         //micem dobiveno iz m_data
         m_data.remove(0,indETB+1);
     }
}

//SALJEM -> DONE
void MainWindow::readySend()
{
    //da ne saljemo prazne poruke
    if (TextLineEdit->text().isEmpty())return;

    //stvaram poruku
    QString message = m_name + ": " + TextLineEdit->text() + "#"; // hasthag oznacava kraj poruke

    //ako je socket konektiram, saljem ju
    if(m_socket->state() == QAbstractSocket::ConnectedState)
       {
           //saljemo podatak i pisemo ga
           m_socket->write(message.toUtf8()); //write the data itself to socket
           writeMessageBox(message, "sent");
           TextLineEdit->clear();
       }else{
         writeMessageBox("You can't text anyone yet. You're not connected!");
        }
}

//------------------------------. funkcije za read/write u LineEdit i PlainTextEdit.-------
void MainWindow::writeMessageBox(QString string)
{
    MessageBox->setTextColor(Qt::black);
    MessageBox->moveCursor (QTextCursor::End);
    MessageBox->insertPlainText(string + "\n");
    MessageBox->moveCursor (QTextCursor::End);
}

void MainWindow::writeMessageBox(QString string, QString user)
{
    if(user=="reply")
    {
        MessageBox->setTextColor(Qt::green);
    }else if (user=="sent")
    {
        MessageBox->setTextColor(Qt::blue);
    }else
    {
        MessageBox->setTextColor(Qt::black);
    }


    MessageBox->moveCursor (QTextCursor::End);
    MessageBox->insertPlainText(string + "\n");
    MessageBox->moveCursor (QTextCursor::End);
}

void MainWindow::lockServerConfiguration()
{
    AdressLineEdit->setReadOnly(true);
    PortSpinBox->setReadOnly(true);
    UserLineEdit->setReadOnly(true);
}

void MainWindow::unlockServerConfiguration()
{
    AdressLineEdit->setReadOnly(false);
    PortSpinBox->setReadOnly(false);
    UserLineEdit->setReadOnly(false);
}

void MainWindow::ClearLineEdits()
{
    AdressLineEdit->clear();
    PortSpinBox->setValue(0);
    UserLineEdit->clear();
}

void MainWindow::ClearSocketStuff()
{
    m_socket = new QTcpSocket();
    m_data.clear();
    m_name.clear();
}
