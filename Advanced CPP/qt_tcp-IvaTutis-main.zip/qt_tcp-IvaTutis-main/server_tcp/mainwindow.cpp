#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow()
{
    setWindowTitle("TcpServer");
    resize(500, 500);

    createWidgets();
    createServerStuff();
    spojiSignale();

    centralWidget  ->setLayout(centralLayout);
    setCentralWidget(centralWidget);

    listen();
}

void MainWindow::createServerStuff()
{
        m_server=new QTcpServer();
}

void MainWindow::createWidgets()
{

    //Inicijalizacija
    centralWidget = new QWidget();
    centralLayout = new QVBoxLayout();
    strip = new QHBoxLayout();
    logEdit = new QPlainTextEdit();
    logEdit->setReadOnly(true);
    logLabel = new QLabel("Log:");
    adressLabel = new QLabel("127.0.0.1");
    portLabel = new QLabel("9090");
    DisconnectButton = new QPushButton("&Disconnect");
    DisconnectButton->setEnabled(false);


    //sada sve stavimo u layoute
    strip->addWidget(adressLabel);
    strip->addWidget(portLabel);
    strip->addStretch();
    strip->addWidget(DisconnectButton);

    centralLayout->addLayout(strip);
    centralLayout->addWidget(logLabel);
    centralLayout->addWidget(logEdit);
}

void MainWindow::spojiSignale()
{
    connect(m_server, &QTcpServer::newConnection, this, &MainWindow::onNewConnection);
    connect(DisconnectButton, &QPushButton::pressed, this, &MainWindow::DisconnectThemAll);
}

//-------------------------------------listen/close----------------------

//DONE
void MainWindow::listen()
{
    if(!m_server->listen(QHostAddress::LocalHost, 9090)){
            logEdit->setPlainText(tr("Server error : %1").arg(m_server->errorString()));
            logEdit->setPlainText(tr("serverError code = ").arg(m_server->serverError()));
            return;
        }
}

//DONE
void MainWindow::close()
{
    m_server->close();
    logEdit->setPlainText("Server closed.");
}

//---------------------------------------kada konekcija radi-----------------
void MainWindow::onNewConnection()
{
    while(m_server->hasPendingConnections()){
           QTcpSocket * socket = m_server->nextPendingConnection();
           m_sockets.push_front(socket); // Zapamti sve sockete
           DisconnectButton->setEnabled(true);
           logEdit->setPlainText(tr("Ostvarena konekcija sa %1 (%2), port %3\n").arg(
                                     socket->peerAddress().toString(), socket->peerName(),
                                     QString::number(socket->peerPort())));

           connect(socket, &QTcpSocket::disconnected, [this, socket](){MainWindow::onDisconnect(socket);});
           connect(socket, &QTcpSocket::readyRead, [this, socket](){MainWindow::onReadyRead(socket);});
       }
}

void MainWindow::onReadyRead(QTcpSocket * socket)
{
    // Znak koji ćemo koristit kao oznaku za kraj poruke.
    const char ETB = 23; // End-of-Transmission-Block character
    if(!socket)
        return;

    // Uzmi referencu na buffer koji odgovara socketu. Ako je ovo prvo čitanje sa socketa
    // kreiraj par (socket, QByteArray{}) i vrati referencu na (prazan) QByteArray.
    QByteArray & buffer = m_data[socket];
    // Pročitaj sve podatke sa socketa.
    buffer.append(socket->readAll());

    // Čitaj kompletne poruke i šalji ih svim priključenim klijentima.
    while(true){
        int end = buffer.indexOf(ETB); // vraća -1 kad ne nađe ETB
        if(end < 0)
            break;
        // Učitaj cijelu poruku u QString
        QString message = QString::fromUtf8(buffer.left(end));
        // Izbaci pročitanu poruku i ETB znak.
        buffer.remove(0, end+1);
        logEdit->appendPlainText(message);
        QByteArray send_msg = message.toUtf8();
        send_msg.append(ETB);
        for(auto * soc : m_sockets){
            if(soc != socket && soc->state() == QAbstractSocket::ConnectedState){
                soc->write(send_msg);
            }
        }
    }
}

void MainWindow::DisconnectThemAll(){
    for(auto * s : m_sockets)
    {
        onDisconnect(s);
    }
    DisconnectButton->setEnabled(false);

}

void MainWindow::onDisconnect(QTcpSocket * socket)
{
    if(!socket)
        return;

    // Obriši socket iz liste socketa
    auto it = std::find(m_sockets.begin(), m_sockets.end(), socket);
    if(it != m_sockets.end())
        m_sockets.erase(it);

    // Obriši spremnik prdružen socketu iz hash mape.
    auto it_d = m_data.find(socket);
    if(it_d != m_data.end())
        m_data.erase(it_d);

    logEdit->appendPlainText(tr("Prekinuta konekcija sa %1, port %2\n").arg(
                              socket->peerAddress().toString(),
                              QString::number(socket->peerPort())));
    DisconnectButton->setEnabled(!m_sockets.empty());
    socket->deleteLater();
}

