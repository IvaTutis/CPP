#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QPlainTextEdit>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QTcpServer>
#include <QTcpSocket>
#include <stdlib.h>
#include <list>
#include <unordered_map>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow();

private:
    Ui::MainWindow *ui;

    QWidget * centralWidget= nullptr;
    QVBoxLayout * centralLayout = nullptr;

    QLabel * adressLabel = nullptr;
    QLabel * portLabel = nullptr;
    QPushButton * DisconnectButton = nullptr;
    QHBoxLayout * strip = nullptr;

    QLabel * logLabel = nullptr;
    QPlainTextEdit * logEdit = nullptr;

    QTcpServer * m_server = nullptr;
    std::list< QTcpSocket *> m_sockets;
    std::unordered_map<QTcpSocket *, QByteArray> m_data;

    //..........f-je

    void createWidgets();
    void createServerStuff();
    void spojiSignale();

    void listen();
    void close();

    void onNewConnection();

    void DisconnectThemAll();
    void onDisconnect(QTcpSocket * socket);
    void onReadyRead(QTcpSocket * socket);

    void writeLog(QString s);


};
#endif // MAINWINDOW_H
