#include "par_any_of.h"
#include "clock.h"

#include <iostream>
#include <future>
#include <vector>
#include <thread>
#include <atomic>
#include <string>
#include <algorithm>  // TREBA DODATI

std::string ispis(bool rjesenje) {
    if (rjesenje) return "True";
    return "False";
}

class MyException : public std::exception
{
public:
    //virtual const char* what() const
    virtual const char* what() const noexcept
    {
        return "hello, from my exception!";
    }
};

//void main() {  NE RADI POD LINUXOM
int  main() {
    // Ovdje u tri primjera treba pokazati korektnost paralelnog algoritma usporedbom
    // sa std::any_of() algoritmom.  U trećem primjeru demonstrirati 
    // propagiranje izuzetka.

    //primjer 1 - trebalo bi izaći 1
    std::cout << "------Primjer-1---------------\n";

    std::vector<int> numbers_1 = { 1, 2, 3, -3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22 };

    Clock sat;
    std::cout << "Rezultat standardnog algoritma je: " << ispis(std::any_of(numbers_1.begin(), numbers_1.end(), [](int i) {return i < 0;})) << "\n";
    double s_1 = sat.stop(sat.microsec);

    sat.start();
    std::cout << "Rezultat paralelnog algoritma je: " << ispis(par_any_of(numbers_1.begin(), numbers_1.end(), [](int i) {return i < 0;})) << "\n";
    double p_1 = sat.stop(sat.microsec);

    std::cout << "Standardnom algoritmu je trebalo " << s_1 << " mikrosekundi, a paralelnom algoritmu je trebalo " << p_1 << " mikrosekundi. \n";

    //primjer 3 - trebalo bi izaći 0
    std::cout << "\n \n ------Primjer-2---------------\n";

    std::vector<int> numbers_2 = {};

    sat.start();
    std::cout << "Rezultat standardnog algoritma je: " << ispis(std::any_of(numbers_2.begin(), numbers_2.end(), [](int i) {return i < 0;})) << "\n";
    double s_2 = sat.stop(sat.microsec);

    sat.start();
    std::cout << "Rezultat paralelnog algoritma je: " << ispis(par_any_of(numbers_2.begin(), numbers_2.end(), [](int i) {return i < 0;})) << "\n";
    double p_2 = sat.stop(sat.microsec);

    std::cout << "Standardnom algoritmu je trebalo " << s_2 << " mikrosekundi, a paralelnom algoritmu je trebalo " << p_2 << " mikrosekundi. \n";

    //primjer 3 - proper handling of exceptions
    std::cout << "\n \n ------Primjer-3---------------\n";

    std::vector<int> numbers_3 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102 };

    sat.start();
    try {
    std::cout << "Rezultat standardnog algoritma je: " << ispis(std::any_of(numbers_3.begin(), numbers_3.end(), [](int i) { throw MyException(); return 1; })) << "\n";
    }
    catch (std::exception& e) {
        std::cout << "Standardni program baca iznimku! \n";
    };
    double s_3 = sat.stop(sat.microsec);

    sat.start();
    try {
        std::cout << "Rezultat paralelnog algoritma je: " << ispis(par_any_of(numbers_3.begin(), numbers_3.end(), [](int i) { throw MyException(); return 1; })) << "\n";
    }
    catch (std::exception& e) {
        std::cout << "Iznimka u paralelnom programu je propagirana! \n";
    };
    double p_3 = sat.stop(sat.microsec);

    std::cout << "Standardnom algoritmu je trebalo " << s_3 << " mikrosekundi, a paralelnom algoritmu je trebalo " << p_3 << " mikrosekundi. \n";

//    return;   SAMO POD WINDOWSIMA
    return 0;
}
