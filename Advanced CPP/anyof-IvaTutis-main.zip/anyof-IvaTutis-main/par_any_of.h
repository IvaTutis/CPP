/* Paralelni any_of() algoritam baziran na promise
   mehanizmu. 
*/

#include <iostream>
#include <future>
#include <vector>
#include <atomic>
#include <cstdlib>
#include <chrono>
#include <algorithm>  // TREBA DODATI

std::atomic<bool> element_found(false);  // GLOBALNE VARIJABLE
std::atomic<int> broj_true_dretvi(0);  // FUNKCIONALNOST KOJU DAJE broj_true_dretvi JEDNOSTAVNO JE 
                                       // MOGLA BITI IMPLEMENTIRANA POMOĆU element_found.


template<class InputIt, class UnaryPredicate>
void block_any_of(InputIt first, InputIt last, UnaryPredicate uvjet, std::promise<bool>&& prom) {
    //poziva any_of nad podnizom

    try {
        bool anyof_result = std::any_of(first, last, uvjet);

        //ako je drugi thread vec nasao value koji odgovara, return
        if (element_found == true) {  // TO JE SUVIŠE KASNO JER JE std::any_of VEĆ SVE ODRADIO
            return;
        }

        //ako je nas thread nasao value, postavi element_found, probaj settati value i return
        if (anyof_result == true) {
            element_found = true;
            try {
                prom.set_value(true);
            }
            catch (const std::future_error& e) {
                //std::cout << "Greska pri postavljanju vrijednosti true u promise \"" << e.code()
                 //   << "\"\nMessage: \"" << e.what() << "\"\n";
            }
            return;
        };

        //ako nas thread nije nasao value, oduzima 1 na broj false dretvi
        broj_true_dretvi--;
        if (broj_true_dretvi != 0)return;

        //ako je ovo prva dretva koja je shvatila da nema elemenata koji odgovaraju
        try {
            prom.set_value(0);
        }
        catch (const std::future_error& e) {
        };

        return;
    }
    catch (std::exception& e) {
        //std::cout << "Standardna greska pri koristenju any_of algoritma";
        try {
            prom.set_exception(std::current_exception());
        }
        catch (const std::future_error& e) {
            return;
        };
            return;
    }
}

template<typename InputIt, typename UnaryPredicate >
bool par_any_of(InputIt first, InputIt last, UnaryPredicate uvjet){
    //provjeravam ima li udaljenosti izmedju dva elementa, ako nema, vracam vrijednost false
    auto length = std::distance(first, last);
    if (!length)
        return false;

    //trazim maksimalni broj threadova, ako je veci od 0, postavljam broj threadova na 2
    int phard = std::thread::hardware_concurrency();
    if (!phard)
        phard = 2;

    //minimalan broj elemenata u svakoj programskoj niti
    int n = 10;
    //maksimalan broj programskih niti
    int pmax = (length > n) ? length / n : 1;
    //konačan broj programskih niti p je minimum između hardverske i maksimalne vrijednosti
    int p = std::min(pmax, phard);

    //counter za broj dretvi koje nemaju element koji odgovara uvjetu je na pocetku p  
    broj_true_dretvi = p;
    //std::cout << "broj dretvi koje cemo pokrenuti je" << p << "\n";
    //std::cout << "broj preostalih dretvi u kojima moze biti broj je" << broj_true_dretvi << "\n";

    //inicijaliziram svoj jedan promise i pripadni future objekt
    std::promise<bool> any_of_promise;
    std::shared_future<bool> any_of_future = any_of_promise.get_future();
 

    std::vector<std::thread> threads(p); // paralelne programske niti

    //veličina svakog podniza je block_size
    auto block_size = length / p;

    //kreiram threadove nad podnizovima, na kraju nad ostatkom niza (zadnji podni) inicijaliziram zadnji thread 
    auto block_first = first;
    auto block_last = block_first;
    for (int i = 0; i < p - 1; ++i) {
        std::advance(block_last, block_size);
        threads[i] = std::thread(block_any_of<InputIt, UnaryPredicate>,
            block_first, block_last, uvjet, std::move(any_of_promise));
        block_first = block_last;
    };
    // OVO JE TREBALO OBAVITI U GLAVNOJ PROGRAMSKOJ NITI
    threads[p-1] = std::thread(block_any_of<InputIt, UnaryPredicate>,
        block_first, last, uvjet, std::move(any_of_promise));


    //future element prima rezultat
    try {
        bool result = any_of_future.get();

        //joinam threadove
        for (int i = 0; i < p; ++i)
            threads[i].join();

        //vracam globalne varijable na staro
        element_found = 0;
        broj_true_dretvi = 0;
 

        // Kad sve dretve završe glavna će vratiti promise value
        return result;

    }catch (const std::future_error& e) {
        //joinam threadove
        for (int i = 0; i < p; ++i)
            threads[i].join();

        //std::cout << "Greska pri dohvacanju promise-a \"" << e.code()
        //<< "\"\nMessage: \"" << e.what() << "\"\n";

        //vracam globalne varijable na staro
        element_found = 0;
        broj_true_dretvi = 0;


        return false;
    }
    catch (const std::exception& e) {
        //std::cout << "Exception from the thread: " << e.what() << '\n';
        

        //joinam threadove
        for (int i = 0; i < p; ++i)
            threads[i].join();



        //vracam globalne varijable na staro
        element_found = 0;
        broj_true_dretvi = 0;

        throw e;
        //return false;
    }
 }
