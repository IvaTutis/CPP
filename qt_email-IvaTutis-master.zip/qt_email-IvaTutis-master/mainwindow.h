#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QTableView>
#include <QStandardItemModel>
#include <QFile>
#include <QStatusBar>

class QMenu;
class QPushButton;

class MainWindow : public QMainWindow{
    Q_OBJECT
    public:
        MainWindow();
    private:
        QWidget * mainWidget = nullptr;

        QVBoxLayout * centralWidgetLayout = nullptr;
        QGridLayout * formLayout = nullptr;
        QHBoxLayout * buttonsLayout = nullptr;

        QLabel * nameLabel = nullptr;
        QLabel * emailLabel = nullptr;
        QLabel * dataLabel = nullptr;

        QLineEdit * nameLineEdit = nullptr;
        QLineEdit * dataLineEdit = nullptr;
        QLineEdit * emailLineEdit = nullptr;

        QTableView * appTable = nullptr;
        QStandardItemModel * appModel = nullptr;

        QPushButton * savePushButton = nullptr;
        QPushButton * clearAllPushButton = nullptr;
        QPushButton * newPushButton = nullptr;

        // Menus
        QMenu * fileMenu = nullptr;
        QMenu * helpMenu = nullptr;

        // Actions
        QAction * quitAction = nullptr;
        QAction * newAction = nullptr;

        QAction * openAction = nullptr;        //filemenu dropdown
        QAction * saveAction = nullptr;        //filemenu dropdown
        QAction * saveasAction = nullptr;        //filemenu dropdown
        QAction * cancelAction = nullptr;
        QAction * aboutAction = nullptr;
        QAction * aboutQtAction = nullptr;

        QAction * saveToolBarAction = nullptr;        //toolbar
        QAction * openToolBarAction = nullptr;        //toolbar
        QAction * deleteAllToolBarAction = nullptr;        //toolbar
        QAction * deleteToolBarAction = nullptr;        //toolbar
        QAction * closeToolBarAction = nullptr;        //toolbar

        // Icons
        QPixmap newIcon;
        QPixmap window_logoIcon;
        QPixmap closeIcon; //filemenu & toolbar
        QPixmap deleteAllIcon;
        QPixmap deleteIcon;
        QPixmap saveIcon; //filemenu
        QPixmap saveasIcon; //filemenu
        QPixmap openIcon; //filemenu

        //validatori
        QValidator *validator_name_data;
        QValidator *validator_email;

        //file
        QString filename;
        QFile file;


        void createIcons();
        void createMenuBar();
        void createToolBar();
        void setupSignalAndSlots();
        void setupCoreWidgets();
        void saveButtonClicked();
        void Save();
        void SaveAs();
        void ClearSpecific();
        void ClearAll();
        void Open();
        void clearFields();
        void MojSignal(QString s);
        void ConvertStringtoTable(QString tekst);

};
#endif // MAINWINDOW_H

