#include "mainwindow.h"

#include <QLabel>
#include <QMenu>
#include <QMenuBar>
#include <QToolBar>
#include <QAction>
#include <QApplication>
#include <QPixmap>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QTableView>    // MVC pattern
#include <QStandardItemModel>
#include <QStandardItem>
#include <QHeaderView>
#include <QMessageBox>
#include <QInputDialog>
#include <QDebug>
#include <QFileDialog>
#include <QFile>

//konstruktor -- DONE
MainWindow::MainWindow(){

    filename = "";

    setWindowTitle("Main Window");
    emit MojSignal("");
    resize(500,500);
    createIcons();
    setWindowIcon(window_logoIcon); //setting the window icon
    createMenuBar();
    createToolBar();
    setupCoreWidgets();
    setupSignalAndSlots();

    mainWidget->setLayout(centralWidgetLayout);
    setCentralWidget(mainWidget);
}

void MainWindow::MojSignal(QString s)
{
    QString base=s.mid(s.lastIndexOf("/")+1);
    statusBar()->showMessage(base);
}

//otvara ikone -- DONE
void MainWindow::createIcons()
{
    newIcon.load(":/Ikone/new.png");
    openIcon.load(":/Ikone/open.png");
    closeIcon.load(":/Ikone/close.png");
    deleteIcon.load(":/Ikone/delete.png");
    deleteAllIcon.load(":/Ikone/clear.png");
    saveIcon.load(":/Ikone/save.png");
    saveasIcon.load(":/Ikone/saveas.png");
    window_logoIcon.load(":/Ikone/window_logo.png");
}

//postavlja menije - DONE
void MainWindow::createMenuBar()
{
    //stvaram menije
    fileMenu = menuBar()->addMenu("&File");
    helpMenu = menuBar()->addMenu("Help");

    //dodajem stvari u fileMenu
    quitAction = new QAction(closeIcon, "Quit", this);
    quitAction->setShortcut(QKeySequence::Quit);

    saveAction = new QAction(saveIcon, "Save", this);
    saveAction->setShortcut(QKeySequence("Save"));

    saveasAction = new QAction(saveasIcon, "Save as", this);
    saveasAction->setShortcut(QKeySequence("Save"));

    openAction = new QAction(openIcon, "&Open", this);
    openAction->setShortcut(Qt::CTRL + Qt::Key_O);

    fileMenu->addAction(saveAction);
    fileMenu->addAction(saveasAction);
    fileMenu->addAction(openAction);
    fileMenu->addSeparator();
    fileMenu->addAction(quitAction);

    //dodajem stvari u helpMenu
    aboutAction = new QAction("About", this); //nema ikone
    aboutAction->setShortcut(Qt::CTRL + Qt::Key_A);

    helpMenu->addAction(aboutAction);

}

//postavlja toolbare - DONE - PROBLEM S PADDINGOM SLIJEVA
void MainWindow::createToolBar()
{
    /* ovo imam definiriano
    QAction * saveToolBarAction = nullptr;        //toolbar
    QAction * openToolBarAction = nullptr;        //toolbar
    QAction * deleteAllToolBarAction = nullptr;        //toolbar
    QAction * deleteToolBarAction = nullptr;        //toolbar
    QAction * closeToolBarAction = nullptr;        //toolbar
    */

    //dodefiniravam actione za toolbar koji jos nisu definirani
    saveToolBarAction = new QAction(saveIcon, "Save", this);
    openToolBarAction = new QAction(openIcon, "Open", this);
    deleteToolBarAction = new QAction(deleteIcon, "Delete", this);
    deleteAllToolBarAction = new QAction(deleteAllIcon, "Clear", this);
    closeToolBarAction = new QAction(closeIcon, "Close", this);


    //definiram toolbar i dodajem stvari u njega
    QToolBar * toolBar = addToolBar("Main tool bar");
    toolBar->setMovable(false);
    toolBar->addAction(saveToolBarAction);
    toolBar->addAction(openToolBarAction);
    toolBar->addSeparator();
    toolBar->addAction(deleteToolBarAction);
    toolBar->addAction(deleteAllToolBarAction);
    toolBar->addAction(closeToolBarAction);
}

//konstruira Core Widget - DONE
void MainWindow::setupCoreWidgets()
{
    //definiramo sastavne blokove
     mainWidget = new QWidget();
     centralWidgetLayout = new QVBoxLayout();
     formLayout = new QGridLayout();

     // Grafički elementi za unos zapisa
        //Labels
     nameLabel = new QLabel("Ime i prezime:");
     emailLabel = new QLabel("email:");
     dataLabel = new QLabel("Napomena:");
        //Line Edits
     nameLineEdit = new QLineEdit();
     emailLineEdit = new QLineEdit();
     dataLineEdit = new QLineEdit();

     //postavljam validatore za lineEdits
     const QString RegEx_for_name_and_data = "^[^,]+$";
     const QString RegEx_for_email = "(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+";

     QRegularExpression r_name_data(RegEx_for_name_and_data);
     QRegularExpression r_email(RegEx_for_email);

     validator_name_data = new QRegularExpressionValidator(r_name_data, this);
     validator_email = new QRegularExpressionValidator(r_email, this);

     nameLineEdit->setValidator(validator_name_data);
     emailLineEdit->setValidator(validator_email);
     dataLineEdit->setValidator(validator_name_data);

     //trpamo u QGridLayout labele i line edite
     formLayout->addWidget(nameLabel, 0,0);
     formLayout->addWidget(nameLineEdit, 0,1);
     formLayout->addWidget(emailLabel, 1,0);
     formLayout->addWidget(emailLineEdit, 1,1);
     formLayout->addWidget(dataLabel, 2,0);
     formLayout->addWidget(dataLineEdit, 2,1);


     centralWidgetLayout->addLayout(formLayout);

    // Grafički elementi za listu zapisa
     appTable = new QTableView();
     appTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
     appTable->setContextMenuPolicy(Qt::CustomContextMenu);
     appModel = new QStandardItemModel(1,3,this);
     appModel->setHorizontalHeaderItem(0, new QStandardItem(QString("Ime i prezime")));
     appModel->setHorizontalHeaderItem(1, new QStandardItem(QString("Email")));
     appModel->setHorizontalHeaderItem(2, new QStandardItem(QString("Napomena")));

     //dodajem prvi item u tablicu
     QStandardItem * first = new QStandardItem(QString("M.Jurak"));
     QStandardItem * second =  new QStandardItem(QString("jurak@math.hr"));
     QStandardItem * third = new QStandardItem(" ... ");
     appModel->setItem(0,0,first);
     appModel->setItem(0,1,second);
     appModel->setItem(0,2,third);

     //dodajem appModel kao model appTable-a
     appTable->setModel(appModel);

     //dodajem appTable u centralni widget
     centralWidgetLayout->addWidget(appTable);

     // Dugmad na dnu prozora
     buttonsLayout = new QHBoxLayout();
     savePushButton = new QPushButton("Save");
     clearAllPushButton = new QPushButton("Clear all");
     buttonsLayout->addStretch();
     buttonsLayout->addWidget(savePushButton);
     buttonsLayout->addWidget(clearAllPushButton);
     centralWidgetLayout->addLayout(buttonsLayout);

}

//povezuje actione/buttone sa funkcijama - provjeriti jel sam sve povezala
void MainWindow::setupSignalAndSlots()
{
    //quitters (1 u toolbaru, 1 u fileMenu)
    connect(quitAction, &QAction::triggered, this, &QApplication::quit);
    connect(closeToolBarAction, &QAction::triggered, this, &QApplication::quit);

    //clearAll/deleteAll (1 u toolbaru, 1 button)
    connect(deleteAllToolBarAction, &QAction::triggered, this, &MainWindow::ClearAll);
    connect(clearAllPushButton, &QPushButton::clicked, this, &MainWindow::ClearAll);

    //clear (baca samo 1 redak 1 kroz input dialog)
    connect(deleteToolBarAction, &QAction::triggered, this, &MainWindow::ClearSpecific);

    //open (1 u fileMenu i 1 u toolbaru)
    connect(openAction, &QAction::triggered, this, &MainWindow::Open);
    connect(openToolBarAction, &QAction::triggered, this, &MainWindow::Open);

    //about (1 u helpMenu) -- DONE
    connect(aboutAction, &QAction::triggered, this, &QApplication::aboutQt);

    //saveButtonClicked (1 button, dodaje u tabelu)
    connect(savePushButton, &QPushButton::clicked, this, &MainWindow::saveButtonClicked);

    //save (1 u toolbaru, 1 fileMenu, sejva u datoteku ili saveas() pokrene)
    connect(saveAction, &QAction::triggered, this, &MainWindow::Save);
    connect(saveToolBarAction, &QAction::triggered, this, &MainWindow::Save);

    //saveAs (1 u fileMenu)
    connect(saveasAction, &QAction::triggered, this, &MainWindow::SaveAs);

    //statusbar_signal
    connect(QMainWindow::statusBar(), SIGNAL(&QStatusBar::messageChanged), this, SLOT(&QStatusBar::showMessage));
}

//DONE - save to table
void MainWindow::saveButtonClicked(){

    //validacija
   if(nameLineEdit->hasAcceptableInput()!=true
           || emailLineEdit->hasAcceptableInput()!=true
             || dataLineEdit->hasAcceptableInput()!= true)
                return;

    //nastavljam sa klasicnom funkcijom
    QString name =nameLineEdit->text();
    QString email = emailLineEdit->text();
    QString data = dataLineEdit->text();

    if(!name.isEmpty() || !email.isEmpty() || !data.isEmpty()){
        QStandardItem * it1{new QStandardItem(name)};
        QStandardItem * it2{new QStandardItem(email)};
        QStandardItem * it3{new QStandardItem(data)};
        appModel->appendRow({it1,it2,it3});
        clearFields();
    }
}

//DONE - clear table
void MainWindow::ClearAll()
{
    int res = QMessageBox::question(this, tr("Clear All"),
                "Do you want to clear all records?",
                                        QMessageBox::Yes| QMessageBox::No, QMessageBox::No);
        if(res == QMessageBox::Yes)
            appModel->removeRows(0, appModel->rowCount());
}

//DONE - clear 1 specific row from table
void MainWindow::ClearSpecific()
{
    bool ok;
    int row = QInputDialog::getInt(this,
                             tr("Izaberi redak za brisanje"),
                             tr("Upišite ID retka koji želite izbrisati (Npr. 1)"),
                             1,1,appModel->rowCount(), 1, &ok);
    if(ok)
            appModel->removeRow(row-1);
}

//DONE - brise sadrzaj polja za upis podataka
void MainWindow::clearFields()
{
    nameLineEdit->clear();
    emailLineEdit->clear();
    dataLineEdit->clear();
}

//DONE - except 4 statusbar signal
void MainWindow::Open()
{
    //odabirem file i otvaram ga
    filename = QFileDialog::getOpenFileName(this, "OpenFile",".","Text files (*.txt)");
    if(filename == ""){
        //ako nema imena
        qDebug() << "Canceled.";
    }
    else{
        //ako je ime odabrano
        file.setFileName(filename);

        //salje signal statusnoj traci
        MojSignal(filename);

        //ucitavam file
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
              qDebug() << "Error.";
        else
              qDebug() << "Opened.";

        QTextStream stream(&file);
        while(!stream.atEnd()){
              QString line = stream.readLine();
              ConvertStringtoTable(line);
        }

        file.close();
    }
}

void MainWindow::Save()
{
    //ako filename nije postavljen, preusmjeri na SaveAs
    if(filename == ""){
        MainWindow::SaveAs();
        return;
    }

    //otvaram potojeći file
    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
          qDebug() << "File 2: Error.";
    else
          qDebug() << "File 2: Opened.";

    //pišem u file
    QTextStream stream2(&file);
    for (int i=0; i<appModel->rowCount(); i++){
        QStandardItem * itemName = appModel->item(i, 0);
        QStandardItem * itemEmail = appModel->item(i, 0);
        QStandardItem * itemData = appModel->item(i, 0);

        stream2 << itemName <<"," <<itemEmail<<","<<itemData;
    }


    //zatvaram file
    file.close();
}

//DONE
void  MainWindow::SaveAs()
{
        filename = QFileDialog::getSaveFileName(this, tr("Save File"),".", tr("Text files (*.txt)"));
        file.setFileName(filename);

        //šalje signal statusnoj traci
        MojSignal(filename);

        //otvori novu datoteku (NewOnly garantira da ju ja stvaram) i piši u nju
        if(!file.open(QIODevice::NewOnly | QIODevice::Text))
              qDebug() << "File 2: Error.";
        else
              qDebug() << "File 2: Opened.";

        //pišem u file
        QTextStream stream2(&file);
        for (int i=0; i<appModel->rowCount(); i++){
            QStandardItem * itemName = appModel->item(i, 0);
            QStandardItem * itemEmail = appModel->item(i, 1);
            QStandardItem * itemData = appModel->item(i, 2);

            stream2 << itemName->text() <<"," <<itemEmail->text()<<","<<itemData->text()<<"\n";
        }

        //zatvaram file
        file.close();
}

//DONE
void MainWindow::ConvertStringtoTable(QString tekst){
    QStringList list = tekst.split(",");

    //jel ih ima 3
    if(list.length()!=3){
        return;
    };

    //nastavljam sa klasicnom funkcijom koja ubacuje novi redak
    QString name =list[0];
    QString email = list[1];
    QString data = list[2];

    //validiram stringove
    int p=0;
    if (validator_name_data->validate(list[0], p)!=QValidator::State::Acceptable
            || validator_name_data->validate(list[2], p)!=QValidator::State::Acceptable
             || validator_email->validate(list[1], p)!=QValidator::State::Acceptable)
        return;


    if(!name.isEmpty() || !email.isEmpty() || !data.isEmpty()){
        QStandardItem * it1{new QStandardItem(name)};
        QStandardItem * it2{new QStandardItem(email)};
        QStandardItem * it3{new QStandardItem(data)};
        appModel->appendRow({it1,it2,it3});
        clearFields();
    }



};



