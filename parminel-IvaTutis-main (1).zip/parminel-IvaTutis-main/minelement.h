/* Kreirati paralelni min_element() algoritam koristeći programske niti. 
 * Vidi https://en.cppreference.com/w/cpp/algorithm/min_element
 */

#include <algorithm>
#include <thread>
#include <vector>
#include <functional>
#include <iostream>

// Serijski min_element() algoritam koji se poziva u svakoj programskoj niti.
template<typename ForwardIt, typename Compare>
void block_min_element(ForwardIt first, ForwardIt last, Compare & result){
    Compare init = 0;
    result = std::min_element(first, last, init);
}
template<typename ForwardIt, typename Compare>
ForwardIt par_min_element(ForwardIt first, ForwardIt last, Compare comp )
{
    //provjeravam ima li udaljenosti izmedju dva elementa, ako nema, vracam vrijednost comp
    auto length = std::distance(first, last);
    if(!length)
        return comp;

    //trazim maksimalni broj threadova, ako je veci od 0, postavljam broj threadova na 2
    int phard = std::thread::hardware_concurrency();
    if(!phard)
        phard = 2;

    //minimalan broj elemenata u svakoj programskoj niti
    int n = 1000;
    //maksimalan broj programskih niti
    int pmax = (length > n) ? length/n : 1;
    //konačan broj programskih niti p je minimum između hardverske i maksimalne vrijednosti
    int p = std::min(pmax, phard);

    std::vector<Compare> results(p); // mjesto za rezultat izračunavanja
    std::vector<std::thread> threads(p-1); // paralelne programske niti

    auto block_size = length/p;
    auto block_first = first;
    auto block_last = block_first;
    for(int i=0; i < p-1; ++i){
        std::advance(block_last, block_size);
        threads[i] = std::thread(block_min_element<ForwardIt, Compare>,
                                 block_first, block_last, std::ref(results[i]));
        block_first = block_last;
        };

    // Tražimo minimum ostatka u glavnoj programskoj niti.
     results[p-1] = std::min_element(block_first, last, Compare());

    for(int i=0; i < p-1; ++i)
            threads[i].join();
        // Kad sve dretve završe glavna će obaviti konačno traženje minimalnog elementa.
        return std::min_element(results.begin(), results.end(), comp);
}
   


   

