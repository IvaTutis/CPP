// Ovdje dolazi vaša klasa Clock.
#include <chrono>

class Clock{
   std::chrono::system_clock::time_point start_vrijeme;
   std::chrono::system_clock::time_point vrijeme;
 public:

    //konstruktori
    Clock();

    //restarta sat
    void restart();

    //čita vrijeme i sprema ga u vrijeme
    std::chrono::system_clock::time_point read_time();

    //čita vrijeme koje je prošlo od starta sata
    std::chrono::system_clock::duration passed_time();


};
