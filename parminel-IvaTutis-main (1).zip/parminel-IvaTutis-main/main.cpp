#include "minelement.h"
#include "random_int.h"
#include "clock.h"
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <chrono>
#include <iterator>
//----------------------funkcije za clock---------------
//konstruktori
Clock::Clock(){
    start_vrijeme = std::chrono::system_clock::now();
    vrijeme = std::chrono::system_clock::now();
};

//restarta sat
void Clock::restart(){
    start_vrijeme = std::chrono::system_clock::now();
    vrijeme = std::chrono::system_clock::now();
};

//čita vrijeme i sprema ga u vrijeme
std::chrono::system_clock::time_point Clock::read_time(){
    vrijeme = std::chrono::system_clock::now();
    return vrijeme;
}

//čita vrijeme koje je prošlo od starta sata
std::chrono::system_clock::duration Clock::passed_time(){
    vrijeme=std::chrono::system_clock::now();
    std::chrono::system_clock::duration d = vrijeme - start_vrijeme;
    return d;
};

//-------------------------------funkcije za RandomInt------------------------
RandomInt::RandomInt(int a, int b){
    std::random_device rd;
    _seed_=rd();
    a_limit=a;
    b_limit=b;
};

RandomInt::RandomInt(RandomInt const & rhs){
    std::random_device rd;
    _seed_=rd();
    a_limit=rhs.a_limit;
    b_limit=rhs.b_limit;
};

// TREBA KORISTITI CHRONO! SEED SE POSTAVLJA SAMO JEDNOM (U KONSTRUKTORU) ! 
// OVO GENERIRA ISTE VRIJEDNOSI.
int  RandomInt::operator()(){
    srand(_seed_);
    int nova_slucajna_vrijednost=rand()%(b_limit - a_limit) + a_limit;
    return nova_slucajna_vrijednost;
    };

//--------------------main------------------------
int main(int argc, char * argv[])
{
  int N = 10000;
  if(argc > 1)
      N = std::atoi(argv[1]);
  
  RandomInt ri(37,3000);   // na primjer
  std::vector<int> source(N); // testirati na tom vektoru
  std::generate(std::begin(source), std::end(source), ri); 


  RandomInt ir(1,100);  // konstrukcija
    std::vector<int> AA(5);
    std::generate(AA.begin(), AA.end(), ir);  // kopiranje u algoritam generate()
    std::copy(AA.begin(), AA.end(), std::ostream_iterator<int>(std::cout, ",")); // ispis
    std::cout << "\n";
    std::generate(AA.begin(), AA.end(), ir);
    std::copy(AA.begin(), AA.end(), std::ostream_iterator<int>(std::cout, ","));
    std::cout << "\n";
    std::generate(AA.begin(), AA.end(), ir);
    std::copy(AA.begin(), AA.end(), std::ostream_iterator<int>(std::cout, ","));
    std::cout << "\n";

    for(int i=0; i<10; ++i)
        std::cout << ir() << ((i ==9) ? "\n" : ",");

  return 0;
}

