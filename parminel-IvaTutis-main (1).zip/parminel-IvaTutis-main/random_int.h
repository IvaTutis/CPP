#include <random>
#include <chrono>
#include <iostream>

// Klasa koja predstavlja generator slučajnih brojeva tipa int uniformno distribuiranih 
// u zadanom rasponu.  Sučelje klase je dano ovdje:
class RandomInt{
    int a_limit;
    int b_limit;
    int _seed_;
  public:
    RandomInt(int a, int b);
    RandomInt(RandomInt const & rhs);
    RandomInt & operator=(RandomInt const & rhs) = delete;
    int operator()();
};
/*
- a, b su granice distribuiranih int-ova;
- konstruktor kopije (i konstruktor) mora postaviti novi _seed_ kako kopija ne bi 
  generirala isti niz kao i original;
- operator() generira novu pseudoslučajnu vrijednost.
*/


