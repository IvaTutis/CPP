#include "clock.h"
#include "paraccumulate.h"
#include <iostream>

// Glavni program koji testira paralelnu verziju accumulate() algoritma.
// Potrebno je na par primjera usporediti serijsku i paralelnu verziju 
// algoritma i usporediti njihova vremena izvršavanja kao funkciju veličine
// spremnika na kojem rade, 

int main(){
    return 0;
}
