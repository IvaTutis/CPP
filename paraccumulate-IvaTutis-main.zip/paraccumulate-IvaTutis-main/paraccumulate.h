// Implementirati parallel_accumulate() algoritam. 
